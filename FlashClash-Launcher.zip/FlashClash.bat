@echo off
title Flash Clash Launcher
echo.
echo  ███████╗██╗      █████╗ ███████╗██╗  ██╗     ██████╗██╗      █████╗ ███████╗██╗  ██╗
echo  ██╔════╝██║     ██╔══██╗██╔════╝██║  ██║    ██╔════╝██║     ██╔══██╗██╔════╝██║  ██║
echo  █████╗  ██║     ███████║███████╗███████║    ██║     ██║     ███████║███████╗███████║
echo  ██╔══╝  ██║     ██╔══██║╚════██║██╔══██║    ██║     ██║     ██╔══██║╚════██║██╔══██║
echo  ██║     ███████╗██║  ██║███████║██║  ██║    ╚██████╗███████╗██║  ██║███████║██║  ██║
echo  ╚═╝     ╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝     ╚═════╝╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
echo.
echo  Milliseconds matter. Prove your reaction speed.
echo  ─────────────────────────────────────────────────────────────────────────────────────
echo.

REM Check PowerShell is available (required)
where powershell >nul 2>&1
if %errorlevel% neq 0 (
    echo  ERROR: PowerShell is not installed or not found in PATH.
    echo  Flash Clash requires PowerShell 5.0 or later.
    echo  Download from: https://aka.ms/powershell
    pause
    exit /b 1
)

REM Launch the PowerShell script
echo  Starting Flash Clash...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0FlashClash.ps1"

if %errorlevel% neq 0 (
    echo.
    echo  Flash Clash exited with an error. See messages above.
    pause
)
