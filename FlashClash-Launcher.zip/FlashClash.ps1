#Requires -Version 5.0
<#
.SYNOPSIS
    Flash Clash Game Launcher
.DESCRIPTION
    Launches the Flash Clash competitive reaction-time game.
    Supports online mode (hosted server) and offline mode (local server).
    Verifies connectivity and displays clear error messages.
.NOTES
    Windows 10 / Windows 11 compatible
    To convert to .exe: see README.txt
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ── Configuration ────────────────────────────────────────────────────────────
$GAME_TITLE   = "Flash Clash"
$GAME_VERSION = "1.0.0"

# Hosted server (your deployed Replit URL — update this after deploying)
$ONLINE_URL   = "https://aakk3.github.io/flashcash"

# Local server (if running the game locally on this PC)
$LOCAL_URL    = "http://localhost:80"
$LOCAL_API    = "http://localhost:8080/api/healthz"

# Required files to verify before launching (relative to this script's directory)
$REQUIRED_FILES = @("FlashClash.ps1", "FlashClash.bat")
# ─────────────────────────────────────────────────────────────────────────────

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Show-Error($title, $message) {
    [System.Windows.Forms.MessageBox]::Show(
        $message, "$GAME_TITLE — $title",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Show-Warning($title, $message) {
    return [System.Windows.Forms.MessageBox]::Show(
        $message, "$GAME_TITLE — $title",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
}

function Show-Info($title, $message) {
    [System.Windows.Forms.MessageBox]::Show(
        $message, "$GAME_TITLE — $title",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

# ── Step 1: Verify required files ────────────────────────────────────────────
Write-Host "[$GAME_TITLE] Verifying game files..." -ForegroundColor Cyan
$missing = @()
foreach ($file in $REQUIRED_FILES) {
    $fullPath = Join-Path $scriptDir $file
    if (-not (Test-Path $fullPath)) {
        $missing += $file
    }
}

if ($missing.Count -gt 0) {
    $fileList = $missing -join "`n  • "
    Show-Error "Missing Files" "The following required files are missing or corrupted:`n`n  • $fileList`n`nPlease reinstall Flash Clash."
    exit 1
}
Write-Host "[$GAME_TITLE] Files OK." -ForegroundColor Green

# ── Step 2: Detect connectivity ───────────────────────────────────────────────
Write-Host "[$GAME_TITLE] Checking connectivity..." -ForegroundColor Cyan

$hasInternet = $false
$localServerUp = $false
$targetUrl = $null

# Check local server first (lower latency)
try {
    $localCheck = Invoke-WebRequest -Uri $LOCAL_API -TimeoutSec 2 -UseBasicParsing -ErrorAction Stop
    if ($localCheck.StatusCode -eq 200) {
        $localServerUp = $true
        $targetUrl = $LOCAL_URL
        Write-Host "[$GAME_TITLE] Local server detected." -ForegroundColor Green
    }
} catch {
    Write-Host "[$GAME_TITLE] No local server found." -ForegroundColor Gray
}

# Check internet / hosted server
if (-not $localServerUp) {
    try {
        $onlineCheck = Invoke-WebRequest -Uri "$ONLINE_URL/api/healthz" -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
        if ($onlineCheck.StatusCode -eq 200) {
            $hasInternet = $true
            $targetUrl = $ONLINE_URL
            Write-Host "[$GAME_TITLE] Online server reachable." -ForegroundColor Green
        }
    } catch {
        Write-Host "[$GAME_TITLE] Online server unreachable: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

# ── Step 3: Handle offline / unreachable ─────────────────────────────────────
if ($null -eq $targetUrl) {
    $choice = Show-Warning "No Connection" @"
Flash Clash could not connect to any game server.

• Online server: $ONLINE_URL (unreachable)
• Local server:  $LOCAL_URL (not running)

Flash Clash requires a server connection to save progress,
track scores, and run matches.

Would you like to try opening the game anyway?
(You may see a connection error page.)
"@
    if ($choice -ne [System.Windows.Forms.DialogResult]::Yes) {
        exit 0
    }
    # Let the user try anyway — use online URL as fallback
    $targetUrl = $ONLINE_URL
}

# ── Step 4: Launch the game ───────────────────────────────────────────────────
Write-Host "[$GAME_TITLE] Launching: $targetUrl" -ForegroundColor Cyan

# Try Chrome in app mode (native-app look with no browser chrome)
$chromePaths = @(
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "$env:PROGRAMFILES\Google\Chrome\Application\chrome.exe",
    "${env:PROGRAMFILES(x86)}\Google\Chrome\Application\chrome.exe"
)
$edgePaths = @(
    "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe",
    "$env:PROGRAMFILES\Microsoft\Edge\Application\msedge.exe",
    "${env:PROGRAMFILES(x86)}\Microsoft\Edge\Application\msedge.exe"
)

$browser = ($chromePaths + $edgePaths) | Where-Object { Test-Path $_ } | Select-Object -First 1

if ($browser) {
    $browserName = if ($browser -like "*chrome*") { "Chrome" } else { "Edge" }
    Write-Host "[$GAME_TITLE] Opening in $browserName app mode..." -ForegroundColor Cyan
    Start-Process $browser "--app=$targetUrl --window-size=1280,800 --window-position=100,50"
} else {
    # Fallback: default browser
    Write-Host "[$GAME_TITLE] Opening in default browser..." -ForegroundColor Cyan
    Start-Process $targetUrl
}

Write-Host "[$GAME_TITLE] Done. Enjoy the game!" -ForegroundColor Green
