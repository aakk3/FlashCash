═══════════════════════════════════════════════════════════════
  FLASH CLASH — Windows Launcher
  Milliseconds matter. Prove your reaction speed.
═══════════════════════════════════════════════════════════════

QUICK START
───────────
Double-click FlashClash.bat to launch the game.

If Windows blocks the script, right-click → "Run as administrator"
or go to:
  Settings → Privacy & Security → Windows Security
  → App & Browser Control → turn off SmartScreen for apps.


HOW IT WORKS
────────────
The launcher:

  1. Verifies required game files are present
  2. Checks for a local game server (if you're running it on this PC)
  3. Checks for the hosted online server
  4. Opens the game in Chrome or Edge in "app mode" (looks native)
  5. Shows clear error messages if the server is unreachable

Online mode:   connects to the hosted Flash Clash server
               (requires internet — saves all progress, scores, cosmetics)

Offline mode:  requires the game server to be running locally
               (advanced — see LOCAL SERVER section below)


CONFIGURATION
─────────────
Edit FlashClash.ps1 to change the game server URL:

  $ONLINE_URL = "https://aakk3.github.io/flashcash"

Update this if the game URL ever changes.


CONVERT TO .EXE (Optional)
───────────────────────────
To create a standalone FlashClash.exe (no .bat file needed):

Method 1 — PS2EXE (Recommended, free):
  1. Open PowerShell as Administrator
  2. Run: Install-Module -Name PS2EXE -Scope CurrentUser
  3. Run: Invoke-PS2EXE FlashClash.ps1 FlashClash.exe -noConsole -iconFile icon.ico
  4. Double-click FlashClash.exe to launch

Method 2 — Inno Setup (creates a proper installer):
  1. Download Inno Setup from https://jrsoftware.org/isinfo.php
  2. Create a script that includes FlashClash.bat and FlashClash.ps1
  3. Compile → produces a Setup.exe installer


LOCAL SERVER (Advanced)
────────────────────────
To play offline or host locally:

  Requirements:
    • Node.js 20+ (https://nodejs.org)
    • PostgreSQL 15+ (https://www.postgresql.org)

  Setup:
    1. Clone the Flash Clash repository
    2. Copy .env.example to .env and fill in DATABASE_URL, SESSION_SECRET
    3. Run: pnpm install
    4. Run: pnpm --filter @workspace/db run push
    5. Run the servers:
         pnpm --filter @workspace/api-server run dev   (port 8080)
         pnpm --filter @workspace/flash-clash run dev  (port 21525)
    6. The launcher will auto-detect and connect to localhost


TROUBLESHOOTING
───────────────
"Execution Policy" error:
  Open PowerShell as Admin and run:
    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

"Cannot connect to server":
  • Check your internet connection
  • Verify the game URL in FlashClash.ps1 ($ONLINE_URL)
  • The hosted server may be temporarily down — try again in a moment

Game opens but shows blank page:
  • Wait a few seconds — the server may be warming up (Replit cold start)
  • Hard refresh: Ctrl + Shift + R

Game is slow or laggy:
  • Close other browser tabs
  • Use a wired internet connection for best reaction-time accuracy


SYSTEM REQUIREMENTS
────────────────────
  OS:       Windows 10 (1903+) or Windows 11
  Browser:  Chrome 90+ or Edge 90+ (auto-detected, or default browser)
  Internet: Required for online mode (10 Mbps+ recommended)
  RAM:      4 GB minimum, 8 GB recommended


═══════════════════════════════════════════════════════════════
  Flash Clash v1.0.0
═══════════════════════════════════════════════════════════════
